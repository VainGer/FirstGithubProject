
function openNav() {
  document.getElementById("nav").style.width = "100%";
}
function closeNav() {
  document.getElementById("nav").style.width = "0%";
}
function openMovies() {
  document.getElementById("movies-menu").style.width = "100%";
}
function closeMovies() {
  document.getElementById("movies-menu").style.width = "0%";
}
function openBooks() {
  document.getElementById("books-menu").style.width = "100%";
}
function closeBooks() {
  document.getElementById("books-menu").style.width = "0%";
}
function openHouse() {
  document.getElementById("house-menu").style.width = "100%";
}
function closeHouse() {
  document.getElementById("house-menu").style.width = "0%";
}
function openSignup() {
  document.getElementById("sign-up").style.display="block";
}
function closeSignup() {
  document.getElementById("sign-up").style.display="none";
}
function openLogin() {
  document.getElementById("have-acc").style.display="block";
}
function closeLogin() {
  document.getElementById("have-acc").style.display="none";
}